package com.anpan.core.common.util

object Constants {
    // API Endpoints
    const val API_VERSION = "v1"
    
    // Pagination
    const val DEFAULT_PAGE_SIZE = 20
    const val MAX_PAGE_SIZE = 100
    
    // Cache
    const val CACHE_TIMEOUT_MINUTES = 30
    
    // Wallet
    const val WALLET_DERIVATION_PATH = "m/44'/60'/0'/0/0"
    
    // Media
    const val MAX_IMAGE_SIZE_MB = 10
    const val MAX_VIDEO_SIZE_MB = 100
    
    // Chat
    const val MAX_MESSAGE_LENGTH = 1000
    const val TYPING_TIMEOUT_MS = 3000L
    
    // Rewards
    const val REWARD_POST = 10
    const val REWARD_COMMENT = 5
    const val REWARD_LIKE = 1
    const val REWARD_SHARE = 3
    
    // Feature Flags
    const val FEATURE_WALLET = "wallet_enabled"
    const val FEATURE_AI_SEARCH = "ai_search_enabled"
    const val FEATURE_VIDEO_CALLS = "video_calls_enabled"
    const val FEATURE_MUSIC_STREAMING = "music_streaming_enabled"
    const val FEATURE_TV_STREAMING = "tv_streaming_enabled"
    const val FEATURE_GAMES = "games_enabled"
    const val FEATURE_MAP = "map_enabled"
    const val FEATURE_REALTY = "realty_enabled"
    const val FEATURE_AGRICULTURE = "agriculture_enabled"
    const val FEATURE_RECRUITMENT = "recruitment_enabled"
    const val FEATURE_WRITING = "writing_enabled"
    const val FEATURE_EDUCATION = "education_enabled"
    const val FEATURE_METAVERSE = "metaverse_enabled"
    const val FEATURE_TIME_MANAGEMENT = "time_management_enabled"
    const val FEATURE_SPACE_TRAVEL = "space_travel_enabled"
    const val FEATURE_MOBILITY = "mobility_enabled"
    const val FEATURE_DIGITAL_LEGACY = "digital_legacy_enabled"
    const val FEATURE_WEARABLES = "wearables_enabled"
    const val FEATURE_ENTERTAINMENT = "entertainment_enabled"
}
