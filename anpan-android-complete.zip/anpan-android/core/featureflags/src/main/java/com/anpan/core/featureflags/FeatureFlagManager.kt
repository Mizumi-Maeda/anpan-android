package com.anpan.core.featureflags

import android.content.Context
import android.content.SharedPreferences
import com.anpan.core.common.util.Constants
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FeatureFlagManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    
    private val prefs: SharedPreferences = context.getSharedPreferences(
        "feature_flags", 
        Context.MODE_PRIVATE
    )
    
    private val _featureFlags = MutableStateFlow(loadFeatureFlags())
    val featureFlags: Flow<Map<String, Boolean>> = _featureFlags.asStateFlow()
    
    private fun loadFeatureFlags(): Map<String, Boolean> {
        return mapOf(
            Constants.FEATURE_WALLET to prefs.getBoolean(Constants.FEATURE_WALLET, true),
            Constants.FEATURE_AI_SEARCH to prefs.getBoolean(Constants.FEATURE_AI_SEARCH, true),
            Constants.FEATURE_VIDEO_CALLS to prefs.getBoolean(Constants.FEATURE_VIDEO_CALLS, true),
            Constants.FEATURE_MUSIC_STREAMING to prefs.getBoolean(Constants.FEATURE_MUSIC_STREAMING, true),
            Constants.FEATURE_TV_STREAMING to prefs.getBoolean(Constants.FEATURE_TV_STREAMING, true),
            Constants.FEATURE_GAMES to prefs.getBoolean(Constants.FEATURE_GAMES, true),
            Constants.FEATURE_MAP to prefs.getBoolean(Constants.FEATURE_MAP, true),
            Constants.FEATURE_REALTY to prefs.getBoolean(Constants.FEATURE_REALTY, true),
            Constants.FEATURE_AGRICULTURE to prefs.getBoolean(Constants.FEATURE_AGRICULTURE, true),
            Constants.FEATURE_RECRUITMENT to prefs.getBoolean(Constants.FEATURE_RECRUITMENT, true),
            Constants.FEATURE_WRITING to prefs.getBoolean(Constants.FEATURE_WRITING, true),
            Constants.FEATURE_EDUCATION to prefs.getBoolean(Constants.FEATURE_EDUCATION, true),
            Constants.FEATURE_METAVERSE to prefs.getBoolean(Constants.FEATURE_METAVERSE, true),
            Constants.FEATURE_TIME_MANAGEMENT to prefs.getBoolean(Constants.FEATURE_TIME_MANAGEMENT, true),
            Constants.FEATURE_SPACE_TRAVEL to prefs.getBoolean(Constants.FEATURE_SPACE_TRAVEL, true),
            Constants.FEATURE_MOBILITY to prefs.getBoolean(Constants.FEATURE_MOBILITY, true),
            Constants.FEATURE_DIGITAL_LEGACY to prefs.getBoolean(Constants.FEATURE_DIGITAL_LEGACY, true),
            Constants.FEATURE_WEARABLES to prefs.getBoolean(Constants.FEATURE_WEARABLES, true),
            Constants.FEATURE_ENTERTAINMENT to prefs.getBoolean(Constants.FEATURE_ENTERTAINMENT, true)
        )
    }
    
    fun isFeatureEnabled(featureKey: String): Boolean {
        return _featureFlags.value[featureKey] ?: false
    }
    
    fun setFeatureEnabled(featureKey: String, enabled: Boolean) {
        prefs.edit().putBoolean(featureKey, enabled).apply()
        _featureFlags.value = _featureFlags.value.toMutableMap().apply {
            this[featureKey] = enabled
        }
    }
    
    fun resetToDefaults() {
        prefs.edit().clear().apply()
        _featureFlags.value = loadFeatureFlags()
    }
    
    // Convenience methods for commonly used features
    fun isWalletEnabled(): Boolean = isFeatureEnabled(Constants.FEATURE_WALLET)
    fun isAISearchEnabled(): Boolean = isFeatureEnabled(Constants.FEATURE_AI_SEARCH)
    fun isVideoCallsEnabled(): Boolean = isFeatureEnabled(Constants.FEATURE_VIDEO_CALLS)
    fun isMusicStreamingEnabled(): Boolean = isFeatureEnabled(Constants.FEATURE_MUSIC_STREAMING)
    fun isTVStreamingEnabled(): Boolean = isFeatureEnabled(Constants.FEATURE_TV_STREAMING)
    fun isGamesEnabled(): Boolean = isFeatureEnabled(Constants.FEATURE_GAMES)
    fun isMapEnabled(): Boolean = isFeatureEnabled(Constants.FEATURE_MAP)
}
