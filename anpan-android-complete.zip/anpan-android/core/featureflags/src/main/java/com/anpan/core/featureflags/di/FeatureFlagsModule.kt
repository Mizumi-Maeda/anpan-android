package com.anpan.core.featureflags.di

import com.anpan.core.featureflags.FeatureFlagManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object FeatureFlagsModule {
    
    @Provides
    @Singleton
    fun provideFeatureFlagManager(
        featureFlagManager: FeatureFlagManager
    ): FeatureFlagManager = featureFlagManager
}
