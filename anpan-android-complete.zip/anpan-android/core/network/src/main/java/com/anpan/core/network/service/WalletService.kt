package com.anpan.core.network.service

import com.anpan.core.network.model.ApiResponse
import com.anpan.core.network.model.PaginatedResponse
import retrofit2.Response
import retrofit2.http.*

interface WalletService {
    
    @POST("wallet/create")
    suspend fun createWallet(
        @Body request: CreateWalletRequest
    ): Response<ApiResponse<Wallet>>
    
    @GET("wallet/balance")
    suspend fun getBalance(): Response<ApiResponse<WalletBalance>>
    
    @POST("wallet/send")
    suspend fun sendTransaction(
        @Body request: SendTransactionRequest
    ): Response<ApiResponse<Transaction>>
    
    @GET("wallet/transactions")
    suspend fun getTransactions(
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 20,
        @Query("type") type: String? = null
    ): Response<ApiResponse<PaginatedResponse<Transaction>>>
    
    @GET("wallet/transactions/{transactionId}")
    suspend fun getTransaction(
        @Path("transactionId") transactionId: String
    ): Response<ApiResponse<Transaction>>
    
    @POST("wallet/payment/stripe")
    suspend fun processStripePayment(
        @Body request: StripePaymentRequest
    ): Response<ApiResponse<PaymentResult>>
    
    @POST("wallet/payment/kabu")
    suspend fun processKabuPayment(
        @Body request: KabuPaymentRequest
    ): Response<ApiResponse<PaymentResult>>
    
    @GET("wallet/rewards")
    suspend fun getRewards(
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 20
    ): Response<ApiResponse<PaginatedResponse<Reward>>>
}

data class Wallet(
    val address: String,
    val publicKey: String,
    val createdAt: Long
)

data class WalletBalance(
    val fiatBalance: Double,
    val fiatCurrency: String,
    val cryptoBalances: List<CryptoBalance>,
    val stockTokens: List<StockToken>
)

data class CryptoBalance(
    val symbol: String,
    val balance: Double,
    val usdValue: Double
)

data class StockToken(
    val symbol: String,
    val shares: Double,
    val currentPrice: Double,
    val totalValue: Double
)

data class Transaction(
    val id: String,
    val type: String,
    val amount: Double,
    val currency: String,
    val fromAddress: String?,
    val toAddress: String?,
    val status: String,
    val hash: String?,
    val blockNumber: Long?,
    val gasUsed: Long?,
    val createdAt: Long,
    val confirmedAt: Long?
)

data class Reward(
    val id: String,
    val type: String,
    val amount: Double,
    val currency: String,
    val description: String,
    val createdAt: Long
)

data class PaymentResult(
    val success: Boolean,
    val transactionId: String?,
    val message: String?
)

data class CreateWalletRequest(
    val publicKey: String
)

data class SendTransactionRequest(
    val toAddress: String,
    val amount: Double,
    val currency: String,
    val memo: String? = null
)

data class StripePaymentRequest(
    val paymentMethodId: String,
    val amount: Double,
    val currency: String,
    val orderId: String
)

data class KabuPaymentRequest(
    val amount: Double,
    val currency: String,
    val orderId: String,
    val signature: String
)
