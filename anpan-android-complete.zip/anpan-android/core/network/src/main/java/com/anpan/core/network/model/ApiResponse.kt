package com.anpan.core.network.model

import com.google.gson.annotations.SerializedName

data class ApiResponse<T>(
    @SerializedName("success")
    val success: Boolean,
    @SerializedName("data")
    val data: T? = null,
    @SerializedName("message")
    val message: String? = null,
    @SerializedName("error")
    val error: String? = null,
    @SerializedName("timestamp")
    val timestamp: Long = System.currentTimeMillis()
)

data class PaginatedResponse<T>(
    @SerializedName("items")
    val items: List<T>,
    @SerializedName("total")
    val total: Int,
    @SerializedName("page")
    val page: Int,
    @SerializedName("pageSize")
    val pageSize: Int,
    @SerializedName("hasNext")
    val hasNext: Boolean
)
