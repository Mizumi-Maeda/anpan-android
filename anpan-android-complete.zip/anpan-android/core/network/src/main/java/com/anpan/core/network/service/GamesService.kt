package com.anpan.core.network.service

import com.anpan.core.network.model.ApiResponse
import com.anpan.core.network.model.PaginatedResponse
import retrofit2.Response
import retrofit2.http.*

interface GamesService {
    
    @GET("games/list")
    suspend fun getGames(
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 20,
        @Query("category") category: String? = null,
        @Query("featured") featured: Boolean? = null
    ): Response<ApiResponse<PaginatedResponse<Game>>>
    
    @GET("games/{gameId}")
    suspend fun getGame(
        @Path("gameId") gameId: String
    ): Response<ApiResponse<Game>>
    
    @POST("games/{gameId}/play")
    suspend fun startGameSession(
        @Path("gameId") gameId: String
    ): Response<ApiResponse<GameSession>>
    
    @PUT("games/sessions/{sessionId}/score")
    suspend fun updateScore(
        @Path("sessionId") sessionId: String,
        @Body request: UpdateScoreRequest
    ): Response<ApiResponse<GameSession>>
    
    @POST("games/sessions/{sessionId}/end")
    suspend fun endGameSession(
        @Path("sessionId") sessionId: String,
        @Body request: EndGameRequest
    ): Response<ApiResponse<GameResult>>
    
    @GET("games/{gameId}/leaderboard")
    suspend fun getLeaderboard(
        @Path("gameId") gameId: String,
        @Query("period") period: String = "all", // daily, weekly, monthly, all
        @Query("limit") limit: Int = 100
    ): Response<ApiResponse<List<LeaderboardEntry>>>
    
    @GET("games/achievements")
    suspend fun getAchievements(
        @Query("gameId") gameId: String? = null
    ): Response<ApiResponse<List<Achievement>>>
    
    @POST("games/achievements/{achievementId}/unlock")
    suspend fun unlockAchievement(
        @Path("achievementId") achievementId: String
    ): Response<ApiResponse<AchievementUnlock>>
    
    @GET("games/rewards")
    suspend fun getGameRewards(
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 20
    ): Response<ApiResponse<PaginatedResponse<GameReward>>>
    
    @POST("games/tournaments/{tournamentId}/join")
    suspend fun joinTournament(
        @Path("tournamentId") tournamentId: String
    ): Response<ApiResponse<TournamentEntry>>
}

data class Game(
    val id: String,
    val name: String,
    val description: String,
    val category: String,
    val thumbnailUrl: String,
    val screenshotUrls: List<String>,
    val unityBundleUrl: String?,
    val webGameUrl: String?,
    val minPlayers: Int,
    val maxPlayers: Int,
    val estimatedPlayTime: Int, // minutes
    val difficulty: String,
    val rating: Double,
    val playCount: Long,
    val rewardTokens: Int,
    val isFeatured: Boolean,
    val isMultiplayer: Boolean,
    val createdAt: Long
)

data class GameSession(
    val id: String,
    val gameId: String,
    val userId: String?,
    val score: Int,
    val level: Int,
    val status: String, // active, paused, completed, abandoned
    val startedAt: Long,
    val lastUpdatedAt: Long,
    val metadata: Map<String, Any>?
)

data class GameResult(
    val sessionId: String,
    val finalScore: Int,
    val finalLevel: Int,
    val playTime: Int, // seconds
    val tokensEarned: Int,
    val achievementsUnlocked: List<Achievement>,
    val leaderboardPosition: Int?,
    val personalBest: Boolean,
    val completedAt: Long
)

data class LeaderboardEntry(
    val rank: Int,
    val userId: String,
    val username: String,
    val userAvatar: String?,
    val score: Int,
    val level: Int,
    val playTime: Int,
    val achievedAt: Long
)

data class Achievement(
    val id: String,
    val gameId: String,
    val name: String,
    val description: String,
    val iconUrl: String,
    val requirement: String,
    val rewardTokens: Int,
    val rarity: String, // common, rare, epic, legendary
    val isUnlocked: Boolean,
    val unlockedAt: Long?
)

data class AchievementUnlock(
    val achievementId: String,
    val tokensEarned: Int,
    val unlockedAt: Long
)

data class GameReward(
    val id: String,
    val gameId: String,
    val type: String, // score, achievement, tournament
    val tokens: Int,
    val description: String,
    val earnedAt: Long
)

data class TournamentEntry(
    val tournamentId: String,
    val userId: String,
    val currentScore: Int,
    val currentRank: Int,
    val joinedAt: Long
)

data class UpdateScoreRequest(
    val score: Int,
    val level: Int,
    val metadata: Map<String, Any>? = null
)

data class EndGameRequest(
    val finalScore: Int,
    val finalLevel: Int,
    val completed: Boolean,
    val metadata: Map<String, Any>? = null
)
