package com.anpan.core.network.service

import com.anpan.core.network.model.ApiResponse
import retrofit2.Response
import retrofit2.http.*

interface AuthService {
    
    @POST("auth/login")
    suspend fun login(
        @Body request: LoginRequest
    ): Response<ApiResponse<LoginResponse>>
    
    @POST("auth/register")
    suspend fun register(
        @Body request: RegisterRequest
    ): Response<ApiResponse<LoginResponse>>
    
    @POST("auth/google")
    suspend fun googleAuth(
        @Body request: GoogleAuthRequest
    ): Response<ApiResponse<LoginResponse>>
    
    @POST("auth/anpan-id")
    suspend fun anpanIdAuth(
        @Body request: AnpanIdAuthRequest
    ): Response<ApiResponse<LoginResponse>>
    
    @POST("auth/refresh")
    suspend fun refreshToken(
        @Body request: RefreshTokenRequest
    ): Response<ApiResponse<LoginResponse>>
    
    @POST("auth/logout")
    suspend fun logout(): Response<ApiResponse<Unit>>
    
    @GET("auth/profile")
    suspend fun getProfile(): Response<ApiResponse<UserProfile>>
    
    @PUT("auth/profile")
    suspend fun updateProfile(
        @Body request: UpdateProfileRequest
    ): Response<ApiResponse<UserProfile>>
}

data class LoginRequest(
    val email: String,
    val password: String
)

data class RegisterRequest(
    val email: String,
    val password: String,
    val displayName: String
)

data class GoogleAuthRequest(
    val idToken: String
)

data class AnpanIdAuthRequest(
    val anpanId: String,
    val signature: String
)

data class RefreshTokenRequest(
    val refreshToken: String
)

data class UpdateProfileRequest(
    val displayName: String?,
    val photoUrl: String?
)

data class LoginResponse(
    val accessToken: String,
    val refreshToken: String,
    val user: UserProfile
)

data class UserProfile(
    val id: String,
    val email: String?,
    val displayName: String?,
    val photoUrl: String?,
    val anpanId: String?,
    val walletAddress: String?,
    val isGuest: Boolean,
    val createdAt: Long,
    val updatedAt: Long
)
