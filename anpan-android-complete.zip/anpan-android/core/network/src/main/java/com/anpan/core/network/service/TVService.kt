package com.anpan.core.network.service

import com.anpan.core.network.model.ApiResponse
import com.anpan.core.network.model.PaginatedResponse
import retrofit2.Response
import retrofit2.http.*

interface TVService {
    
    @GET("tv/content")
    suspend fun getContent(
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 20,
        @Query("type") type: String? = null, // movie, series, live
        @Query("genre") genre: String? = null,
        @Query("search") search: String? = null
    ): Response<ApiResponse<PaginatedResponse<TVContent>>>
    
    @GET("tv/content/{contentId}")
    suspend fun getContent(
        @Path("contentId") contentId: String
    ): Response<ApiResponse<TVContent>>
    
    @GET("tv/live-streams")
    suspend fun getLiveStreams(
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 20,
        @Query("category") category: String? = null
    ): Response<ApiResponse<PaginatedResponse<LiveStream>>>
    
    @POST("tv/live-streams")
    suspend fun createLiveStream(
        @Body request: CreateLiveStreamRequest
    ): Response<ApiResponse<LiveStream>>
    
    @PUT("tv/live-streams/{streamId}/status")
    suspend fun updateStreamStatus(
        @Path("streamId") streamId: String,
        @Body request: UpdateStreamStatusRequest
    ): Response<ApiResponse<LiveStream>>
    
    @POST("tv/content/{contentId}/watch")
    suspend fun recordWatch(
        @Path("contentId") contentId: String,
        @Body request: WatchRecordRequest
    ): Response<ApiResponse<WatchRecord>>
    
    @POST("tv/live-streams/{streamId}/tip")
    suspend fun sendTip(
        @Path("streamId") streamId: String,
        @Body request: SendTipRequest
    ): Response<ApiResponse<Tip>>
    
    @GET("tv/watchlist")
    suspend fun getWatchlist(
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 20
    ): Response<ApiResponse<PaginatedResponse<TVContent>>>
    
    @POST("tv/watchlist/{contentId}")
    suspend fun addToWatchlist(
        @Path("contentId") contentId: String
    ): Response<ApiResponse<Unit>>
    
    @DELETE("tv/watchlist/{contentId}")
    suspend fun removeFromWatchlist(
        @Path("contentId") contentId: String
    ): Response<ApiResponse<Unit>>
}

data class TVContent(
    val id: String,
    val title: String,
    val description: String,
    val type: String, // movie, series, documentary
    val genre: String,
    val duration: Int?, // minutes for movies, null for series
    val releaseDate: Long,
    val rating: String, // G, PG, PG-13, R, etc.
    val thumbnailUrl: String,
    val trailerUrl: String?,
    val streamUrl: String,
    val drmLicenseUrl: String?,
    val cast: List<CastMember>,
    val director: String?,
    val producer: String?,
    val studio: String,
    val seasons: List<Season>?, // for series
    val viewCount: Long,
    val averageRating: Double,
    val isInWatchlist: Boolean
)

data class CastMember(
    val name: String,
    val role: String,
    val imageUrl: String?
)

data class Season(
    val number: Int,
    val title: String,
    val episodes: List<Episode>
)

data class Episode(
    val id: String,
    val number: Int,
    val title: String,
    val description: String,
    val duration: Int, // minutes
    val streamUrl: String,
    val thumbnailUrl: String,
    val airDate: Long
)

data class LiveStream(
    val id: String,
    val title: String,
    val description: String,
    val category: String,
    val streamUrl: String,
    val thumbnailUrl: String,
    val streamer: UserProfile,
    val viewerCount: Int,
    val status: String, // live, scheduled, ended
    val scheduledAt: Long?,
    val startedAt: Long?,
    val endedAt: Long?,
    val totalTips: Double,
    val isSubscribed: Boolean
)

data class WatchRecord(
    val id: String,
    val contentId: String,
    val userId: String?,
    val duration: Int, // seconds watched
    val progress: Double, // 0.0 to 1.0
    val completed: Boolean,
    val watchedAt: Long
)

data class Tip(
    val id: String,
    val streamId: String,
    val fromUserId: String?,
    val amount: Double,
    val currency: String,
    val message: String?,
    val createdAt: Long
)

data class CreateLiveStreamRequest(
    val title: String,
    val description: String,
    val category: String,
    val scheduledAt: Long?
)

data class UpdateStreamStatusRequest(
    val status: String
)

data class WatchRecordRequest(
    val duration: Int,
    val progress: Double,
    val completed: Boolean
)

data class SendTipRequest(
    val amount: Double,
    val currency: String,
    val message: String?
)
