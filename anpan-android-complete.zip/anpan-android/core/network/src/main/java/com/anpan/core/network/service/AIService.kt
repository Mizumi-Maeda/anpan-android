package com.anpan.core.network.service

import com.anpan.core.network.model.ApiResponse
import retrofit2.Response
import retrofit2.http.*

interface AIService {
    
    @POST("ai/search")
    suspend fun naturalLanguageSearch(
        @Body request: SearchRequest
    ): Response<ApiResponse<SearchResponse>>
    
    @GET("ai/recommendations/feed")
    suspend fun getFeedRecommendations(
        @Query("userId") userId: String? = null,
        @Query("limit") limit: Int = 20
    ): Response<ApiResponse<List<RecommendationItem>>>
    
    @GET("ai/recommendations/products")
    suspend fun getProductRecommendations(
        @Query("userId") userId: String? = null,
        @Query("category") category: String? = null,
        @Query("limit") limit: Int = 20
    ): Response<ApiResponse<List<Product>>>
    
    @POST("ai/analyze/content")
    suspend fun analyzeContent(
        @Body request: ContentAnalysisRequest
    ): Response<ApiResponse<ContentAnalysis>>
    
    @POST("ai/generate/caption")
    suspend fun generateCaption(
        @Body request: CaptionGenerationRequest
    ): Response<ApiResponse<GeneratedCaption>>
    
    @POST("ai/translate")
    suspend fun translateText(
        @Body request: TranslationRequest
    ): Response<ApiResponse<TranslationResponse>>
    
    @POST("ai/summarize")
    suspend fun summarizeText(
        @Body request: SummarizationRequest
    ): Response<ApiResponse<SummarizationResponse>>
}

data class SearchRequest(
    val query: String,
    val type: String = "all", // all, posts, products, users
    val filters: Map<String, Any> = emptyMap()
)

data class SearchResponse(
    val query: String,
    val results: List<SearchResult>,
    val suggestions: List<String>,
    val totalResults: Int
)

data class SearchResult(
    val type: String,
    val id: String,
    val title: String,
    val description: String,
    val imageUrl: String?,
    val score: Double,
    val metadata: Map<String, Any>
)

data class RecommendationItem(
    val type: String,
    val id: String,
    val title: String,
    val description: String,
    val imageUrl: String?,
    val score: Double,
    val reason: String
)

data class ContentAnalysisRequest(
    val content: String,
    val mediaUrls: List<String> = emptyList()
)

data class ContentAnalysis(
    val sentiment: String,
    val topics: List<String>,
    val entities: List<Entity>,
    val language: String,
    val appropriateness: Boolean,
    val suggestedTags: List<String>
)

data class Entity(
    val text: String,
    val type: String,
    val confidence: Double
)

data class CaptionGenerationRequest(
    val imageUrl: String,
    val style: String = "casual" // casual, professional, creative
)

data class GeneratedCaption(
    val caption: String,
    val alternatives: List<String>,
    val hashtags: List<String>
)

data class TranslationRequest(
    val text: String,
    val fromLanguage: String,
    val toLanguage: String
)

data class TranslationResponse(
    val translatedText: String,
    val confidence: Double,
    val detectedLanguage: String?
)

data class SummarizationRequest(
    val text: String,
    val maxLength: Int = 100,
    val style: String = "bullet_points" // paragraph, bullet_points, key_points
)

data class SummarizationResponse(
    val summary: String,
    val keyPoints: List<String>,
    val originalLength: Int,
    val summaryLength: Int
)
