package com.anpan.core.network.service

import com.anpan.core.network.model.ApiResponse
import com.anpan.core.network.model.PaginatedResponse
import retrofit2.Response
import retrofit2.http.*

interface MapService {
    
    @GET("map/places")
    suspend fun searchPlaces(
        @Query("query") query: String,
        @Query("lat") latitude: Double,
        @Query("lng") longitude: Double,
        @Query("radius") radius: Int = 5000, // meters
        @Query("category") category: String? = null,
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 20
    ): Response<ApiResponse<PaginatedResponse<Place>>>
    
    @GET("map/places/{placeId}")
    suspend fun getPlace(
        @Path("placeId") placeId: String
    ): Response<ApiResponse<Place>>
    
    @POST("map/places/{placeId}/checkin")
    suspend fun checkIn(
        @Path("placeId") placeId: String,
        @Body request: CheckInRequest
    ): Response<ApiResponse<CheckIn>>
    
    @GET("map/checkins")
    suspend fun getCheckIns(
        @Query("userId") userId: String? = null,
        @Query("placeId") placeId: String? = null,
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 20
    ): Response<ApiResponse<PaginatedResponse<CheckIn>>>
    
    @GET("map/nearby-users")
    suspend fun getNearbyUsers(
        @Query("lat") latitude: Double,
        @Query("lng") longitude: Double,
        @Query("radius") radius: Int = 1000 // meters
    ): Response<ApiResponse<List<NearbyUser>>>
    
    @POST("map/share-location")
    suspend fun shareLocation(
        @Body request: ShareLocationRequest
    ): Response<ApiResponse<Unit>>
    
    @DELETE("map/share-location")
    suspend fun stopSharingLocation(): Response<ApiResponse<Unit>>
    
    @GET("map/routes")
    suspend fun getRoute(
        @Query("fromLat") fromLatitude: Double,
        @Query("fromLng") fromLongitude: Double,
        @Query("toLat") toLatitude: Double,
        @Query("toLng") toLongitude: Double,
        @Query("mode") mode: String = "driving" // driving, walking, cycling, transit
    ): Response<ApiResponse<Route>>
    
    @POST("map/places/{placeId}/review")
    suspend fun addReview(
        @Path("placeId") placeId: String,
        @Body request: AddReviewRequest
    ): Response<ApiResponse<Review>>
    
    @GET("map/places/{placeId}/reviews")
    suspend fun getReviews(
        @Path("placeId") placeId: String,
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 20
    ): Response<ApiResponse<PaginatedResponse<Review>>>
}

data class Place(
    val id: String,
    val name: String,
    val description: String?,
    val category: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val phone: String?,
    val website: String?,
    val imageUrls: List<String>,
    val rating: Double,
    val reviewCount: Int,
    val priceLevel: Int?, // 1-4, null if not applicable
    val openingHours: List<OpeningHour>?,
    val amenities: List<String>,
    val checkInCount: Int,
    val distance: Double?, // meters from user's location
    val isOpen: Boolean?,
    val popularTimes: List<PopularTime>?
)

data class OpeningHour(
    val dayOfWeek: Int, // 0 = Sunday, 1 = Monday, etc.
    val openTime: String, // "09:00"
    val closeTime: String // "17:00"
)

data class PopularTime(
    val dayOfWeek: Int,
    val hour: Int, // 0-23
    val popularity: Int // 0-100
)

data class CheckIn(
    val id: String,
    val placeId: String,
    val userId: String?,
    val message: String?,
    val imageUrl: String?,
    val latitude: Double,
    val longitude: Double,
    val createdAt: Long,
    val user: UserProfile?,
    val place: Place
)

data class NearbyUser(
    val userId: String,
    val username: String,
    val avatar: String?,
    val latitude: Double,
    val longitude: Double,
    val distance: Double, // meters
    val lastSeen: Long,
    val status: String? // custom status message
)

data class Route(
    val distance: Double, // meters
    val duration: Int, // seconds
    val polyline: String, // encoded polyline
    val steps: List<RouteStep>,
    val bounds: RouteBounds
)

data class RouteStep(
    val instruction: String,
    val distance: Double,
    val duration: Int,
    val startLocation: LatLng,
    val endLocation: LatLng
)

data class RouteBounds(
    val northeast: LatLng,
    val southwest: LatLng
)

data class LatLng(
    val latitude: Double,
    val longitude: Double
)

data class Review(
    val id: String,
    val placeId: String,
    val userId: String?,
    val rating: Int, // 1-5
    val comment: String?,
    val imageUrls: List<String>,
    val createdAt: Long,
    val user: UserProfile?
)

data class CheckInRequest(
    val message: String?,
    val imageUrl: String?,
    val latitude: Double,
    val longitude: Double
)

data class ShareLocationRequest(
    val latitude: Double,
    val longitude: Double,
    val accuracy: Float,
    val duration: Int? = null // minutes, null for indefinite
)

data class AddReviewRequest(
    val rating: Int,
    val comment: String?,
    val imageUrls: List<String> = emptyList()
)
