package com.anpan.core.network.service

import com.anpan.core.network.model.ApiResponse
import com.anpan.core.network.model.PaginatedResponse
import retrofit2.Response
import retrofit2.http.*

interface MusicService {
    
    @GET("music/tracks")
    suspend fun getTracks(
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 20,
        @Query("genre") genre: String? = null,
        @Query("search") search: String? = null
    ): Response<ApiResponse<PaginatedResponse<Track>>>
    
    @GET("music/tracks/{trackId}")
    suspend fun getTrack(
        @Path("trackId") trackId: String
    ): Response<ApiResponse<Track>>
    
    @GET("music/albums")
    suspend fun getAlbums(
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 20,
        @Query("artistId") artistId: String? = null
    ): Response<ApiResponse<PaginatedResponse<Album>>>
    
    @GET("music/albums/{albumId}")
    suspend fun getAlbum(
        @Path("albumId") albumId: String
    ): Response<ApiResponse<Album>>
    
    @GET("music/playlists")
    suspend fun getPlaylists(
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 20,
        @Query("userId") userId: String? = null
    ): Response<ApiResponse<PaginatedResponse<Playlist>>>
    
    @POST("music/playlists")
    suspend fun createPlaylist(
        @Body request: CreatePlaylistRequest
    ): Response<ApiResponse<Playlist>>
    
    @PUT("music/playlists/{playlistId}")
    suspend fun updatePlaylist(
        @Path("playlistId") playlistId: String,
        @Body request: UpdatePlaylistRequest
    ): Response<ApiResponse<Playlist>>
    
    @POST("music/playlists/{playlistId}/tracks")
    suspend fun addTrackToPlaylist(
        @Path("playlistId") playlistId: String,
        @Body request: AddTrackRequest
    ): Response<ApiResponse<Unit>>
    
    @DELETE("music/playlists/{playlistId}/tracks/{trackId}")
    suspend fun removeTrackFromPlaylist(
        @Path("playlistId") playlistId: String,
        @Path("trackId") trackId: String
    ): Response<ApiResponse<Unit>>
    
    @POST("music/tracks/{trackId}/play")
    suspend fun recordPlay(
        @Path("trackId") trackId: String,
        @Body request: PlayRecordRequest
    ): Response<ApiResponse<PlayRecord>>
    
    @GET("music/royalties")
    suspend fun getRoyalties(
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 20
    ): Response<ApiResponse<PaginatedResponse<Royalty>>>
}

data class Track(
    val id: String,
    val title: String,
    val artist: Artist,
    val album: Album?,
    val duration: Int, // seconds
    val genre: String,
    val streamUrl: String,
    val coverImageUrl: String?,
    val playCount: Long,
    val royaltyRate: Double,
    val cryptoRoyaltyToken: String?,
    val createdAt: Long
)

data class Artist(
    val id: String,
    val name: String,
    val bio: String?,
    val imageUrl: String?,
    val verified: Boolean
)

data class Album(
    val id: String,
    val title: String,
    val artist: Artist,
    val tracks: List<Track>?,
    val coverImageUrl: String?,
    val releaseDate: Long,
    val genre: String
)

data class Playlist(
    val id: String,
    val name: String,
    val description: String?,
    val coverImageUrl: String?,
    val tracks: List<Track>?,
    val isPublic: Boolean,
    val createdBy: UserProfile,
    val createdAt: Long,
    val updatedAt: Long
)

data class PlayRecord(
    val id: String,
    val trackId: String,
    val userId: String?,
    val duration: Int, // seconds played
    val royaltyEarned: Double,
    val cryptoRoyaltyEarned: Double?,
    val playedAt: Long
)

data class Royalty(
    val id: String,
    val trackId: String,
    val artistId: String,
    val amount: Double,
    val currency: String,
    val cryptoAmount: Double?,
    val cryptoToken: String?,
    val period: String,
    val createdAt: Long
)

data class CreatePlaylistRequest(
    val name: String,
    val description: String?,
    val isPublic: Boolean = true
)

data class UpdatePlaylistRequest(
    val name: String?,
    val description: String?,
    val isPublic: Boolean?
)

data class AddTrackRequest(
    val trackId: String
)

data class PlayRecordRequest(
    val duration: Int,
    val completed: Boolean
)
