package com.anpan.core.network.service

import com.anpan.core.network.model.ApiResponse
import com.anpan.core.network.model.PaginatedResponse
import retrofit2.Response
import retrofit2.http.*

interface SocialService {
    
    @GET("social/feed")
    suspend fun getFeed(
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 20,
        @Query("userId") userId: String? = null
    ): Response<ApiResponse<PaginatedResponse<Post>>>
    
    @POST("social/posts")
    suspend fun createPost(
        @Body request: CreatePostRequest
    ): Response<ApiResponse<Post>>
    
    @GET("social/posts/{postId}")
    suspend fun getPost(
        @Path("postId") postId: String
    ): Response<ApiResponse<Post>>
    
    @PUT("social/posts/{postId}")
    suspend fun updatePost(
        @Path("postId") postId: String,
        @Body request: UpdatePostRequest
    ): Response<ApiResponse<Post>>
    
    @DELETE("social/posts/{postId}")
    suspend fun deletePost(
        @Path("postId") postId: String
    ): Response<ApiResponse<Unit>>
    
    @POST("social/posts/{postId}/like")
    suspend fun likePost(
        @Path("postId") postId: String
    ): Response<ApiResponse<Unit>>
    
    @DELETE("social/posts/{postId}/like")
    suspend fun unlikePost(
        @Path("postId") postId: String
    ): Response<ApiResponse<Unit>>
    
    @POST("social/posts/{postId}/share")
    suspend fun sharePost(
        @Path("postId") postId: String,
        @Body request: SharePostRequest
    ): Response<ApiResponse<Unit>>
    
    @GET("social/posts/{postId}/comments")
    suspend fun getComments(
        @Path("postId") postId: String,
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 20
    ): Response<ApiResponse<PaginatedResponse<Comment>>>
    
    @POST("social/posts/{postId}/comments")
    suspend fun createComment(
        @Path("postId") postId: String,
        @Body request: CreateCommentRequest
    ): Response<ApiResponse<Comment>>
    
    @GET("social/products")
    suspend fun getProducts(
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 20,
        @Query("category") category: String? = null,
        @Query("search") search: String? = null
    ): Response<ApiResponse<PaginatedResponse<Product>>>
    
    @GET("social/products/{productId}")
    suspend fun getProduct(
        @Path("productId") productId: String
    ): Response<ApiResponse<Product>>
    
    @POST("social/cart/add")
    suspend fun addToCart(
        @Body request: AddToCartRequest
    ): Response<ApiResponse<Unit>>
    
    @GET("social/cart")
    suspend fun getCart(): Response<ApiResponse<Cart>>
    
    @POST("social/checkout")
    suspend fun checkout(
        @Body request: CheckoutRequest
    ): Response<ApiResponse<Order>>
}

data class Post(
    val id: String,
    val userId: String?,
    val content: String,
    val mediaUrls: List<String>,
    val productTags: List<ProductTag>,
    val likesCount: Int,
    val commentsCount: Int,
    val sharesCount: Int,
    val isLiked: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    val user: UserProfile?
)

data class Comment(
    val id: String,
    val postId: String,
    val userId: String?,
    val content: String,
    val createdAt: Long,
    val user: UserProfile?
)

data class Product(
    val id: String,
    val name: String,
    val description: String,
    val price: Double,
    val currency: String,
    val imageUrls: List<String>,
    val category: String,
    val stock: Int,
    val rating: Double,
    val reviewsCount: Int
)

data class ProductTag(
    val productId: String,
    val x: Float,
    val y: Float
)

data class Cart(
    val items: List<CartItem>,
    val total: Double,
    val currency: String
)

data class CartItem(
    val productId: String,
    val quantity: Int,
    val price: Double,
    val product: Product
)

data class Order(
    val id: String,
    val items: List<CartItem>,
    val total: Double,
    val currency: String,
    val status: String,
    val createdAt: Long
)

data class CreatePostRequest(
    val content: String,
    val mediaUrls: List<String> = emptyList(),
    val productTags: List<ProductTag> = emptyList()
)

data class UpdatePostRequest(
    val content: String,
    val productTags: List<ProductTag> = emptyList()
)

data class SharePostRequest(
    val message: String? = null
)

data class CreateCommentRequest(
    val content: String
)

data class AddToCartRequest(
    val productId: String,
    val quantity: Int
)

data class CheckoutRequest(
    val paymentMethod: String,
    val shippingAddress: Address
)

data class Address(
    val street: String,
    val city: String,
    val state: String,
    val zipCode: String,
    val country: String
)
