package com.anpan.core.network.di

import com.anpan.core.network.BuildConfig
import com.anpan.core.network.interceptor.AuthInterceptor
import com.anpan.core.network.service.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {
    
    @Provides
    @Singleton
    fun provideHttpLoggingInterceptor(): HttpLoggingInterceptor {
        return HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) {
                HttpLoggingInterceptor.Level.BODY
            } else {
                HttpLoggingInterceptor.Level.NONE
            }
        }
    }
    
    @Provides
    @Singleton
    fun provideOkHttpClient(
        loggingInterceptor: HttpLoggingInterceptor,
        authInterceptor: AuthInterceptor
    ): OkHttpClient {
        return OkHttpClient.Builder()
            .addInterceptor(authInterceptor)
            .addInterceptor(loggingInterceptor)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }
    
    @Provides
    @Singleton
    fun provideRetrofit(okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BuildConfig.API_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }
    
    @Provides
    @Singleton
    fun provideAuthService(retrofit: Retrofit): AuthService = retrofit.create(AuthService::class.java)
    
    @Provides
    @Singleton
    fun provideSocialService(retrofit: Retrofit): SocialService = retrofit.create(SocialService::class.java)
    
    @Provides
    @Singleton
    fun provideWalletService(retrofit: Retrofit): WalletService = retrofit.create(WalletService::class.java)
    
    @Provides
    @Singleton
    fun provideAIService(retrofit: Retrofit): AIService = retrofit.create(AIService::class.java)
    
    @Provides
    @Singleton
    fun provideChatService(retrofit: Retrofit): ChatService = retrofit.create(ChatService::class.java)
    
    @Provides
    @Singleton
    fun provideMusicService(retrofit: Retrofit): MusicService = retrofit.create(MusicService::class.java)
    
    @Provides
    @Singleton
    fun provideTVService(retrofit: Retrofit): TVService = retrofit.create(TVService::class.java)
    
    @Provides
    @Singleton
    fun provideGamesService(retrofit: Retrofit): GamesService = retrofit.create(GamesService::class.java)
    
    @Provides
    @Singleton
    fun provideMapService(retrofit: Retrofit): MapService = retrofit.create(MapService::class.java)
}
