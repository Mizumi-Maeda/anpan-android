package com.anpan.core.network.service

import com.anpan.core.network.model.ApiResponse
import com.anpan.core.network.model.PaginatedResponse
import retrofit2.Response
import retrofit2.http.*

interface ChatService {
    
    @GET("chat/conversations")
    suspend fun getConversations(
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 20
    ): Response<ApiResponse<PaginatedResponse<Conversation>>>
    
    @POST("chat/conversations")
    suspend fun createConversation(
        @Body request: CreateConversationRequest
    ): Response<ApiResponse<Conversation>>
    
    @GET("chat/conversations/{conversationId}")
    suspend fun getConversation(
        @Path("conversationId") conversationId: String
    ): Response<ApiResponse<Conversation>>
    
    @GET("chat/conversations/{conversationId}/messages")
    suspend fun getMessages(
        @Path("conversationId") conversationId: String,
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 50,
        @Query("before") before: Long? = null
    ): Response<ApiResponse<PaginatedResponse<Message>>>
    
    @POST("chat/conversations/{conversationId}/messages")
    suspend fun sendMessage(
        @Path("conversationId") conversationId: String,
        @Body request: SendMessageRequest
    ): Response<ApiResponse<Message>>
    
    @POST("chat/video-call/initiate")
    suspend fun initiateVideoCall(
        @Body request: InitiateCallRequest
    ): Response<ApiResponse<CallSession>>
    
    @POST("chat/video-call/join")
    suspend fun joinVideoCall(
        @Body request: JoinCallRequest
    ): Response<ApiResponse<CallSession>>
    
    @POST("chat/video-call/end")
    suspend fun endVideoCall(
        @Body request: EndCallRequest
    ): Response<ApiResponse<Unit>>
    
    @GET("chat/video-call/{callId}/token")
    suspend fun getCallToken(
        @Path("callId") callId: String
    ): Response<ApiResponse<CallToken>>
    
    @POST("chat/commerce/show-product")
    suspend fun showProductInCall(
        @Body request: ShowProductRequest
    ): Response<ApiResponse<Unit>>
}

data class Conversation(
    val id: String,
    val type: String, // direct, group
    val name: String?,
    val participants: List<UserProfile>,
    val lastMessage: Message?,
    val unreadCount: Int,
    val createdAt: Long,
    val updatedAt: Long
)

data class Message(
    val id: String,
    val conversationId: String,
    val senderId: String?,
    val type: String, // text, image, video, audio, product, system
    val content: String,
    val mediaUrl: String?,
    val productId: String?,
    val metadata: Map<String, Any>?,
    val createdAt: Long,
    val sender: UserProfile?
)

data class CallSession(
    val id: String,
    val conversationId: String,
    val type: String, // video, audio
    val status: String, // initiated, active, ended
    val participants: List<CallParticipant>,
    val agoraChannelName: String,
    val createdAt: Long,
    val endedAt: Long?
)

data class CallParticipant(
    val userId: String,
    val status: String, // invited, joined, left
    val joinedAt: Long?,
    val leftAt: Long?,
    val user: UserProfile
)

data class CallToken(
    val token: String,
    val channelName: String,
    val uid: Int,
    val expiresAt: Long
)

data class CreateConversationRequest(
    val type: String,
    val name: String?,
    val participantIds: List<String>
)

data class SendMessageRequest(
    val type: String,
    val content: String,
    val mediaUrl: String? = null,
    val productId: String? = null,
    val metadata: Map<String, Any>? = null
)

data class InitiateCallRequest(
    val conversationId: String,
    val type: String // video, audio
)

data class JoinCallRequest(
    val callId: String
)

data class EndCallRequest(
    val callId: String
)

data class ShowProductRequest(
    val callId: String,
    val productId: String
)
