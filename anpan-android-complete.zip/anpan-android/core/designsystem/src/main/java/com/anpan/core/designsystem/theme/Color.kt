package com.anpan.core.designsystem.theme

import androidx.compose.ui.graphics.Color

// Primary Colors
val AnpanPrimary = Color(0xFF6750A4)
val AnpanPrimaryVariant = Color(0xFF3700B3)
val AnpanOnPrimary = Color(0xFFFFFFFF)

// Secondary Colors
val AnpanSecondary = Color(0xFF625B71)
val AnpanSecondaryVariant = Color(0xFF03DAC6)
val AnpanOnSecondary = Color(0xFFFFFFFF)

// Background Colors
val AnpanBackground = Color(0xFFFFFBFE)
val AnpanOnBackground = Color(0xFF1C1B1F)
val AnpanSurface = Color(0xFFFFFBFE)
val AnpanOnSurface = Color(0xFF1C1B1F)

// Error Colors
val AnpanError = Color(0xFFB3261E)
val AnpanOnError = Color(0xFFFFFFFF)

// Success Colors
val AnpanSuccess = Color(0xFF4CAF50)
val AnpanOnSuccess = Color(0xFFFFFFFF)

// Warning Colors
val AnpanWarning = Color(0xFFFF9800)
val AnpanOnWarning = Color(0xFFFFFFFF)

// Info Colors
val AnpanInfo = Color(0xFF2196F3)
val AnpanOnInfo = Color(0xFFFFFFFF)

// Wallet Colors
val WalletGreen = Color(0xFF4CAF50)
val WalletRed = Color(0xFFF44336)
val WalletBlue = Color(0xFF2196F3)
val WalletGold = Color(0xFFFFD700)

// Social Colors
val LikeRed = Color(0xFFE91E63)
val ShareBlue = Color(0xFF2196F3)
val CommentGray = Color(0xFF757575)

// Dark Theme Colors
val AnpanPrimaryDark = Color(0xFFD0BCFF)
val AnpanSecondaryDark = Color(0xFFCCC2DC)
val AnpanBackgroundDark = Color(0xFF1C1B1F)
val AnpanSurfaceDark = Color(0xFF1C1B1F)
val AnpanOnBackgroundDark = Color(0xFFE6E1E5)
val AnpanOnSurfaceDark = Color(0xFFE6E1E5)
