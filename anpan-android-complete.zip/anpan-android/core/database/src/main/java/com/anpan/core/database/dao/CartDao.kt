package com.anpan.core.database.dao

import androidx.room.*
import com.anpan.core.database.entity.CartItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CartDao {
    
    @Query("SELECT * FROM cart_items ORDER BY addedAt DESC")
    suspend fun getCartItems(): List<CartItemEntity>
    
    @Query("SELECT * FROM cart_items ORDER BY addedAt DESC")
    fun getCartItemsFlow(): Flow<List<CartItemEntity>>
    
    @Query("SELECT * FROM cart_items WHERE productId = :productId")
    suspend fun getCartItemByProduct(productId: String): CartItemEntity?
    
    @Query("SELECT COUNT(*) FROM cart_items")
    suspend fun getCartItemCount(): Int
    
    @Query("SELECT COUNT(*) FROM cart_items")
    fun getCartItemCountFlow(): Flow<Int>
    
    @Query("SELECT SUM(price * quantity) FROM cart_items")
    suspend fun getCartTotal(): Double?
    
    @Query("SELECT SUM(price * quantity) FROM cart_items")
    fun getCartTotalFlow(): Flow<Double?>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCartItem(cartItem: CartItemEntity)
    
    @Update
    suspend fun updateCartItem(cartItem: CartItemEntity)
    
    @Delete
    suspend fun deleteCartItem(cartItem: CartItemEntity)
    
    @Query("DELETE FROM cart_items")
    suspend fun clearCart()
    
    @Query("UPDATE cart_items SET quantity = :quantity WHERE productId = :productId")
    suspend fun updateQuantity(productId: String, quantity: Int)
}
