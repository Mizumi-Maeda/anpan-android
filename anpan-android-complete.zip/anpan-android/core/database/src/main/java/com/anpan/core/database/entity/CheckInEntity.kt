package com.anpan.core.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "checkins")
data class CheckInEntity(
    @PrimaryKey
    val id: String,
    val placeId: String,
    val placeName: String,
    val userId: String?,
    val message: String?,
    val imageUrl: String?,
    val latitude: Double,
    val longitude: Double,
    val createdAt: Long
)
