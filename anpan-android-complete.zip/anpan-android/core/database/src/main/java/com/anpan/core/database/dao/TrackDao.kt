package com.anpan.core.database.dao

import androidx.room.*
import com.anpan.core.database.entity.TrackEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TrackDao {
    
    @Query("SELECT * FROM tracks ORDER BY lastPlayed DESC")
    suspend fun getAllTracks(): List<TrackEntity>
    
    @Query("SELECT * FROM tracks WHERE id = :trackId")
    suspend fun getTrackById(trackId: String): TrackEntity?
    
    @Query("SELECT * FROM tracks WHERE isDownloaded = 1")
    suspend fun getDownloadedTracks(): List<TrackEntity>
    
    @Query("SELECT * FROM tracks WHERE isDownloaded = 1")
    fun getDownloadedTracksFlow(): Flow<List<TrackEntity>>
    
    @Query("SELECT * FROM tracks WHERE genre = :genre")
    suspend fun getTracksByGenre(genre: String): List<TrackEntity>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrack(track: TrackEntity)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTracks(tracks: List<TrackEntity>)
    
    @Update
    suspend fun updateTrack(track: TrackEntity)
    
    @Delete
    suspend fun deleteTrack(track: TrackEntity)
    
    @Query("UPDATE tracks SET lastPlayed = :timestamp WHERE id = :trackId")
    suspend fun updateLastPlayed(trackId: String, timestamp: Long)
    
    @Query("UPDATE tracks SET isDownloaded = :isDownloaded, downloadPath = :path WHERE id = :trackId")
    suspend fun updateDownloadStatus(trackId: String, isDownloaded: Boolean, path: String?)
    
    @Query("SELECT * FROM tracks WHERE title LIKE '%' || :query || '%' OR artistName LIKE '%' || :query || '%'")
    suspend fun searchTracks(query: String): List<TrackEntity>
}
