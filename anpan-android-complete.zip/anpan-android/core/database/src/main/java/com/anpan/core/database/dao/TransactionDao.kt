package com.anpan.core.database.dao

import androidx.room.*
import com.anpan.core.database.entity.TransactionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    
    @Query("SELECT * FROM transactions ORDER BY createdAt DESC")
    suspend fun getAllTransactions(): List<TransactionEntity>
    
    @Query("SELECT * FROM transactions ORDER BY createdAt DESC")
    fun getAllTransactionsFlow(): Flow<List<TransactionEntity>>
    
    @Query("SELECT * FROM transactions WHERE id = :transactionId")
    suspend fun getTransactionById(transactionId: String): TransactionEntity?
    
    @Query("SELECT * FROM transactions WHERE type = :type ORDER BY createdAt DESC")
    suspend fun getTransactionsByType(type: String): List<TransactionEntity>
    
    @Query("SELECT * FROM transactions WHERE status = :status ORDER BY createdAt DESC")
    suspend fun getTransactionsByStatus(status: String): List<TransactionEntity>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(transactions: List<TransactionEntity>)
    
    @Update
    suspend fun updateTransaction(transaction: TransactionEntity)
    
    @Delete
    suspend fun deleteTransaction(transaction: TransactionEntity)
    
    @Query("UPDATE transactions SET status = :status, confirmedAt = :confirmedAt WHERE id = :transactionId")
    suspend fun updateTransactionStatus(transactionId: String, status: String, confirmedAt: Long?)
}
