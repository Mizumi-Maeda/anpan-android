package com.anpan.core.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "game_sessions")
data class GameSessionEntity(
    @PrimaryKey
    val id: String,
    val gameId: String,
    val userId: String?,
    val score: Int,
    val level: Int,
    val status: String,
    val startedAt: Long,
    val lastUpdatedAt: Long,
    val metadata: String? // JSON string
)
