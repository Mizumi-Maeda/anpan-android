package com.anpan.core.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey
    val id: String,
    val type: String,
    val amount: Double,
    val currency: String,
    val fromAddress: String?,
    val toAddress: String?,
    val status: String,
    val hash: String?,
    val blockNumber: Long?,
    val gasUsed: Long?,
    val createdAt: Long,
    val confirmedAt: Long?
)
