package com.anpan.core.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val description: String?,
    val coverImageUrl: String?,
    val trackIds: List<String>,
    val isPublic: Boolean,
    val createdBy: String,
    val createdAt: Long,
    val updatedAt: Long
)
