package com.anpan.core.database.dao

import androidx.room.*
import com.anpan.core.database.entity.PlaylistEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaylistDao {
    
    @Query("SELECT * FROM playlists ORDER BY updatedAt DESC")
    suspend fun getAllPlaylists(): List<PlaylistEntity>
    
    @Query("SELECT * FROM playlists ORDER BY updatedAt DESC")
    fun getAllPlaylistsFlow(): Flow<List<PlaylistEntity>>
    
    @Query("SELECT * FROM playlists WHERE id = :playlistId")
    suspend fun getPlaylistById(playlistId: String): PlaylistEntity?
    
    @Query("SELECT * FROM playlists WHERE createdBy = :userId ORDER BY updatedAt DESC")
    suspend fun getPlaylistsByUser(userId: String): List<PlaylistEntity>
    
    @Query("SELECT * FROM playlists WHERE isPublic = 1 ORDER BY updatedAt DESC")
    suspend fun getPublicPlaylists(): List<PlaylistEntity>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylists(playlists: List<PlaylistEntity>)
    
    @Update
    suspend fun updatePlaylist(playlist: PlaylistEntity)
    
    @Delete
    suspend fun deletePlaylist(playlist: PlaylistEntity)
    
    @Query("UPDATE playlists SET trackIds = :trackIds, updatedAt = :timestamp WHERE id = :playlistId")
    suspend fun updatePlaylistTracks(playlistId: String, trackIds: List<String>, timestamp: Long)
}
