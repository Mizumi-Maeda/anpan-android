package com.anpan.core.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "posts")
data class PostEntity(
    @PrimaryKey
    val id: String,
    val userId: String?,
    val content: String,
    val mediaUrls: List<String>,
    val productTags: List<String>, // JSON string of product tags
    val likesCount: Int,
    val commentsCount: Int,
    val sharesCount: Int,
    val isLiked: Boolean,
    val createdAt: Long,
    val updatedAt: Long
)
