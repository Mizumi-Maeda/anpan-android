package com.anpan.core.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey
    val id: String,
    val conversationId: String,
    val senderId: String?,
    val type: String,
    val content: String,
    val mediaUrl: String?,
    val productId: String?,
    val metadata: String?, // JSON string
    val createdAt: Long,
    val isRead: Boolean = false
)
