package com.anpan.core.database.dao

import androidx.room.*
import com.anpan.core.database.entity.CheckInEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CheckInDao {
    
    @Query("SELECT * FROM checkins ORDER BY createdAt DESC")
    suspend fun getAllCheckIns(): List<CheckInEntity>
    
    @Query("SELECT * FROM checkins ORDER BY createdAt DESC")
    fun getAllCheckInsFlow(): Flow<List<CheckInEntity>>
    
    @Query("SELECT * FROM checkins WHERE id = :checkInId")
    suspend fun getCheckInById(checkInId: String): CheckInEntity?
    
    @Query("SELECT * FROM checkins WHERE placeId = :placeId ORDER BY createdAt DESC")
    suspend fun getCheckInsByPlace(placeId: String): List<CheckInEntity>
    
    @Query("SELECT * FROM checkins WHERE userId = :userId ORDER BY createdAt DESC")
    suspend fun getCheckInsByUser(userId: String): List<CheckInEntity>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCheckIn(checkIn: CheckInEntity)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCheckIns(checkIns: List<CheckInEntity>)
    
    @Update
    suspend fun updateCheckIn(checkIn: CheckInEntity)
    
    @Delete
    suspend fun deleteCheckIn(checkIn: CheckInEntity)
    
    @Query("DELETE FROM checkins WHERE createdAt < :timestamp")
    suspend fun deleteOldCheckIns(timestamp: Long)
}
