package com.anpan.core.database

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import android.content.Context
import com.anpan.core.database.dao.*
import com.anpan.core.database.entity.*
import com.anpan.core.database.converter.Converters

@Database(
    entities = [
        UserEntity::class,
        PostEntity::class,
        CommentEntity::class,
        ProductEntity::class,
        CartItemEntity::class,
        TransactionEntity::class,
        ConversationEntity::class,
        MessageEntity::class,
        TrackEntity::class,
        PlaylistEntity::class,
        GameSessionEntity::class,
        CheckInEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AnpanDatabase : RoomDatabase() {
    
    abstract fun userDao(): UserDao
    abstract fun postDao(): PostDao
    abstract fun commentDao(): CommentDao
    abstract fun productDao(): ProductDao
    abstract fun cartDao(): CartDao
    abstract fun transactionDao(): TransactionDao
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    abstract fun trackDao(): TrackDao
    abstract fun playlistDao(): PlaylistDao
    abstract fun gameDao(): GameDao
    abstract fun checkInDao(): CheckInDao
    
    companion object {
        const val DATABASE_NAME = "anpan_database"
    }
}
