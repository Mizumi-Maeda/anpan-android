package com.anpan.core.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val description: String,
    val price: Double,
    val currency: String,
    val imageUrls: List<String>,
    val category: String,
    val stock: Int,
    val rating: Double,
    val reviewsCount: Int,
    val isFavorite: Boolean = false,
    val lastViewed: Long? = null
)
