package com.anpan.core.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey
    val id: String,
    val type: String,
    val name: String?,
    val participantIds: List<String>,
    val lastMessageId: String?,
    val unreadCount: Int,
    val createdAt: Long,
    val updatedAt: Long
)
