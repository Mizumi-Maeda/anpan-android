package com.anpan.core.database.dao

import androidx.room.*
import com.anpan.core.database.entity.GameSessionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface GameDao {
    
    @Query("SELECT * FROM game_sessions ORDER BY lastUpdatedAt DESC")
    suspend fun getAllGameSessions(): List<GameSessionEntity>
    
    @Query("SELECT * FROM game_sessions WHERE id = :sessionId")
    suspend fun getGameSessionById(sessionId: String): GameSessionEntity?
    
    @Query("SELECT * FROM game_sessions WHERE gameId = :gameId ORDER BY lastUpdatedAt DESC")
    suspend fun getGameSessionsByGame(gameId: String): List<GameSessionEntity>
    
    @Query("SELECT * FROM game_sessions WHERE userId = :userId ORDER BY lastUpdatedAt DESC")
    suspend fun getGameSessionsByUser(userId: String): List<GameSessionEntity>
    
    @Query("SELECT * FROM game_sessions WHERE status = 'active'")
    suspend fun getActiveGameSessions(): List<GameSessionEntity>
    
    @Query("SELECT * FROM game_sessions WHERE status = 'active'")
    fun getActiveGameSessionsFlow(): Flow<List<GameSessionEntity>>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGameSession(session: GameSessionEntity)
    
    @Update
    suspend fun updateGameSession(session: GameSessionEntity)
    
    @Delete
    suspend fun deleteGameSession(session: GameSessionEntity)
    
    @Query("UPDATE game_sessions SET score = :score, level = :level, lastUpdatedAt = :timestamp WHERE id = :sessionId")
    suspend fun updateGameProgress(sessionId: String, score: Int, level: Int, timestamp: Long)
    
    @Query("UPDATE game_sessions SET status = :status, lastUpdatedAt = :timestamp WHERE id = :sessionId")
    suspend fun updateGameStatus(sessionId: String, status: String, timestamp: Long)
}
