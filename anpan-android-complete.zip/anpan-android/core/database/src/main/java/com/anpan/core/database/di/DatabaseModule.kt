package com.anpan.core.database.di

import android.content.Context
import androidx.room.Room
import com.anpan.core.database.AnpanDatabase
import com.anpan.core.database.dao.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    
    @Provides
    @Singleton
    fun provideAnpanDatabase(@ApplicationContext context: Context): AnpanDatabase {
        return Room.databaseBuilder(
            context,
            AnpanDatabase::class.java,
            AnpanDatabase.DATABASE_NAME
        ).build()
    }
    
    @Provides
    fun provideUserDao(database: AnpanDatabase): UserDao = database.userDao()
    
    @Provides
    fun providePostDao(database: AnpanDatabase): PostDao = database.postDao()
    
    @Provides
    fun provideCommentDao(database: AnpanDatabase): CommentDao = database.commentDao()
    
    @Provides
    fun provideProductDao(database: AnpanDatabase): ProductDao = database.productDao()
    
    @Provides
    fun provideCartDao(database: AnpanDatabase): CartDao = database.cartDao()
    
    @Provides
    fun provideTransactionDao(database: AnpanDatabase): TransactionDao = database.transactionDao()
    
    @Provides
    fun provideConversationDao(database: AnpanDatabase): ConversationDao = database.conversationDao()
    
    @Provides
    fun provideMessageDao(database: AnpanDatabase): MessageDao = database.messageDao()
    
    @Provides
    fun provideTrackDao(database: AnpanDatabase): TrackDao = database.trackDao()
    
    @Provides
    fun providePlaylistDao(database: AnpanDatabase): PlaylistDao = database.playlistDao()
    
    @Provides
    fun provideGameDao(database: AnpanDatabase): GameDao = database.gameDao()
    
    @Provides
    fun provideCheckInDao(database: AnpanDatabase): CheckInDao = database.checkInDao()
}
