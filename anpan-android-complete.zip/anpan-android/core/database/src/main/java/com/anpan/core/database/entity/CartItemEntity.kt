package com.anpan.core.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cart_items")
data class CartItemEntity(
    @PrimaryKey
    val id: String,
    val productId: String,
    val quantity: Int,
    val price: Double,
    val addedAt: Long = System.currentTimeMillis()
)
