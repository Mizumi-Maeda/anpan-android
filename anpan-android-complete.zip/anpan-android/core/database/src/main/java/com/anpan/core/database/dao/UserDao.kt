package com.anpan.core.database.dao

import androidx.room.*
import com.anpan.core.database.entity.UserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    
    @Query("SELECT * FROM users WHERE id = :userId")
    suspend fun getUserById(userId: String): UserEntity?
    
    @Query("SELECT * FROM users WHERE id = :userId")
    fun getUserByIdFlow(userId: String): Flow<UserEntity?>
    
    @Query("SELECT * FROM users WHERE email = :email")
    suspend fun getUserByEmail(email: String): UserEntity?
    
    @Query("SELECT * FROM users WHERE anpanId = :anpanId")
    suspend fun getUserByAnpanId(anpanId: String): UserEntity?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)
    
    @Update
    suspend fun updateUser(user: UserEntity)
    
    @Delete
    suspend fun deleteUser(user: UserEntity)
    
    @Query("DELETE FROM users")
    suspend fun deleteAllUsers()
    
    @Query("SELECT * FROM users WHERE isGuest = 0")
    suspend fun getRegisteredUsers(): List<UserEntity>
    
    @Query("UPDATE users SET accessToken = :token WHERE id = :userId")
    suspend fun updateAccessToken(userId: String, token: String?)
    
    @Query("UPDATE users SET refreshToken = :token WHERE id = :userId")
    suspend fun updateRefreshToken(userId: String, token: String?)
}
