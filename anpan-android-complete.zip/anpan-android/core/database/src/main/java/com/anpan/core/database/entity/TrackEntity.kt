package com.anpan.core.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tracks")
data class TrackEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val artistName: String,
    val albumName: String?,
    val duration: Int,
    val genre: String,
    val streamUrl: String,
    val coverImageUrl: String?,
    val playCount: Long,
    val isDownloaded: Boolean = false,
    val downloadPath: String? = null,
    val lastPlayed: Long? = null
)
