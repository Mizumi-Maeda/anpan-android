from PIL import Image
import os

dirs = ['app/src/main/res/mipmap-hdpi', 'app/src/main/res/mipmap-mdpi', 'app/src/main/res/mipmap-xhdpi', 'app/src/main/res/mipmap-xxhdpi', 'app/src/main/res/mipmap-xxxhdpi']
for d in dirs:
    os.makedirs(d, exist_ok=True)

sizes = [(72, 'hdpi'), (48, 'mdpi'), (96, 'xhdpi'), (144, 'xxhdpi'), (192, 'xxxhdpi')]
for size, density in sizes:
    img = Image.new('RGB', (size, size), color='#2196F3')
    img.save(f'app/src/main/res/mipmap-{density}/ic_launcher.png')
    img.save(f'app/src/main/res/mipmap-{density}/ic_launcher_round.png')
    print(f'Created {density} icons ({size}x{size})')

print("All launcher icons created successfully!")
