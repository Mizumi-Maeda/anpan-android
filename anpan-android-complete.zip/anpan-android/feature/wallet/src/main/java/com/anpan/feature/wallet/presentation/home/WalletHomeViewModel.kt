package com.anpan.feature.wallet.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.anpan.core.common.result.Result
import com.anpan.core.network.service.Transaction
import com.anpan.core.network.service.WalletBalance
import com.anpan.feature.wallet.domain.repository.WalletRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class WalletHomeViewModel @Inject constructor(
    private val walletRepository: WalletRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(WalletHomeUiState())
    val uiState: StateFlow<WalletHomeUiState> = _uiState.asStateFlow()
    
    init {
        loadWalletData()
    }
    
    fun loadWalletData() {
        _uiState.value = _uiState.value.copy(isLoading = true)
        
        viewModelScope.launch {
            // Load balance
            when (val balanceResult = walletRepository.getBalance()) {
                is Result.Success -> {
                    _uiState.value = _uiState.value.copy(
                        balance = balanceResult.data,
                        isLoading = false
                    )
                }
                is Result.Error -> {
                    _uiState.value = _uiState.value.copy(
                        error = balanceResult.exception.message,
                        isLoading = false
                    )
                }
                is Result.Loading -> {
                    // Already handled above
                }
            }
            
            // Load recent transactions
            when (val transactionsResult = walletRepository.getTransactions(1, 10, null)) {
                is Result.Success -> {
                    _uiState.value = _uiState.value.copy(
                        recentTransactions = transactionsResult.data
                    )
                }
                is Result.Error -> {
                    // Don't override main error if balance failed
                    if (_uiState.value.error == null) {
                        _uiState.value = _uiState.value.copy(
                            error = transactionsResult.exception.message
                        )
                    }
                }
                is Result.Loading -> {
                    // Already handled above
                }
            }
        }
    }
    
    fun onRefresh() {
        loadWalletData()
    }
    
    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }
}

data class WalletHomeUiState(
    val balance: WalletBalance? = null,
    val recentTransactions: List<Transaction> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)
