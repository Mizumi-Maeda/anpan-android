package com.anpan.feature.wallet.domain.repository

import com.anpan.core.common.result.Result
import com.anpan.core.network.service.*
import kotlinx.coroutines.flow.Flow

interface WalletRepository {
    
    suspend fun createWallet(): Result<Wallet>
    suspend fun getBalance(): Result<WalletBalance>
    fun getBalanceFlow(): Flow<WalletBalance?>
    suspend fun sendTransaction(toAddress: String, amount: Double, currency: String, memo: String?): Result<Transaction>
    suspend fun getTransactions(page: Int, pageSize: Int, type: String?): Result<List<Transaction>>
    fun getTransactionsFlow(): Flow<List<Transaction>>
    suspend fun getTransaction(transactionId: String): Result<Transaction>
    suspend fun processStripePayment(paymentMethodId: String, amount: Double, currency: String, orderId: String): Result<PaymentResult>
    suspend fun processKabuPayment(amount: Double, currency: String, orderId: String): Result<PaymentResult>
    suspend fun getRewards(page: Int, pageSize: Int): Result<List<Reward>>
    fun getRewardsFlow(): Flow<List<Reward>>
    suspend fun generateWalletAddress(): String
    suspend fun signTransaction(transaction: String, privateKey: String): String
    suspend fun validateAddress(address: String): Boolean
    suspend fun estimateGasFee(toAddress: String, amount: Double): Result<Double>
    suspend fun getExchangeRates(): Result<Map<String, Double>>
    suspend fun exportPrivateKey(): Result<String>
    suspend fun importPrivateKey(privateKey: String): Result<Wallet>
    suspend fun backupWallet(): Result<String>
    suspend fun restoreWallet(backup: String): Result<Wallet>
}
