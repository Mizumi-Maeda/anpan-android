package com.anpan.feature.auth.domain.usecase

import com.anpan.core.common.model.User
import com.anpan.core.common.result.Result
import com.anpan.feature.auth.domain.repository.AuthRepository
import javax.inject.Inject

class LoginAsGuestUseCase @Inject constructor(
    private val authRepository: AuthRepository
) {
    suspend operator fun invoke(): Result<User> {
        return authRepository.loginAsGuest()
    }
}
