package com.anpan.feature.auth.domain.usecase

import com.anpan.core.common.model.User
import com.anpan.core.common.result.Result
import com.anpan.feature.auth.domain.repository.AuthRepository
import javax.inject.Inject

class RegisterWithEmailUseCase @Inject constructor(
    private val authRepository: AuthRepository
) {
    suspend operator fun invoke(email: String, password: String, displayName: String): Result<User> {
        if (email.isBlank()) {
            return Result.Error(IllegalArgumentException("Email cannot be empty"))
        }
        
        if (password.isBlank()) {
            return Result.Error(IllegalArgumentException("Password cannot be empty"))
        }
        
        if (displayName.isBlank()) {
            return Result.Error(IllegalArgumentException("Display name cannot be empty"))
        }
        
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            return Result.Error(IllegalArgumentException("Invalid email format"))
        }
        
        if (password.length < 6) {
            return Result.Error(IllegalArgumentException("Password must be at least 6 characters"))
        }
        
        return authRepository.registerWithEmail(email, password, displayName)
    }
}
