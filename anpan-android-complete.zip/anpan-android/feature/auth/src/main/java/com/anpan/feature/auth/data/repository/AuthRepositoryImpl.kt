package com.anpan.feature.auth.data.repository

import com.anpan.core.common.di.IoDispatcher
import com.anpan.core.common.model.User
import com.anpan.core.common.result.Result
import com.anpan.core.database.dao.UserDao
import com.anpan.core.database.entity.UserEntity
import com.anpan.core.network.interceptor.AuthInterceptor
import com.anpan.core.network.service.AuthService
import com.anpan.feature.auth.domain.repository.AuthRepository
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import kotlinx.coroutines.tasks.await
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthRepositoryImpl @Inject constructor(
    private val authService: AuthService,
    private val userDao: UserDao,
    private val authInterceptor: AuthInterceptor,
    private val firebaseAuth: FirebaseAuth,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : AuthRepository {
    
    override suspend fun loginWithEmail(email: String, password: String): Result<User> {
        return withContext(ioDispatcher) {
            try {
                // Firebase Auth
                val authResult = firebaseAuth.signInWithEmailAndPassword(email, password).await()
                val firebaseUser = authResult.user ?: throw Exception("Firebase user is null")
                
                // Get ID token for API
                val idToken = firebaseUser.getIdToken(false).await().token
                
                // Call API
                val response = authService.login(
                    com.anpan.core.network.service.LoginRequest(email, password)
                )
                
                if (response.isSuccessful && response.body()?.success == true) {
                    val loginResponse = response.body()!!.data!!
                    
                    // Save to local database
                    val userEntity = UserEntity(
                        id = loginResponse.user.id,
                        email = loginResponse.user.email,
                        displayName = loginResponse.user.displayName,
                        photoUrl = loginResponse.user.photoUrl,
                        isGuest = false,
                        anpanId = loginResponse.user.anpanId,
                        walletAddress = loginResponse.user.walletAddress,
                        accessToken = loginResponse.accessToken,
                        refreshToken = loginResponse.refreshToken
                    )
                    userDao.insertUser(userEntity)
                    
                    // Set auth token for API calls
                    authInterceptor.setAuthToken(loginResponse.accessToken)
                    
                    Result.Success(userEntity.toUser())
                } else {
                    Result.Error(Exception(response.body()?.error ?: "Login failed"))
                }
            } catch (e: Exception) {
                Result.Error(e)
            }
        }
    }
    
    override suspend fun registerWithEmail(email: String, password: String, displayName: String): Result<User> {
        return withContext(ioDispatcher) {
            try {
                // Firebase Auth
                val authResult = firebaseAuth.createUserWithEmailAndPassword(email, password).await()
                val firebaseUser = authResult.user ?: throw Exception("Firebase user is null")
                
                // Update profile
                val profileUpdates = com.google.firebase.auth.UserProfileChangeRequest.Builder()
                    .setDisplayName(displayName)
                    .build()
                firebaseUser.updateProfile(profileUpdates).await()
                
                // Call API
                val response = authService.register(
                    com.anpan.core.network.service.RegisterRequest(email, password, displayName)
                )
                
                if (response.isSuccessful && response.body()?.success == true) {
                    val loginResponse = response.body()!!.data!!
                    
                    // Save to local database
                    val userEntity = UserEntity(
                        id = loginResponse.user.id,
                        email = loginResponse.user.email,
                        displayName = loginResponse.user.displayName,
                        photoUrl = loginResponse.user.photoUrl,
                        isGuest = false,
                        anpanId = loginResponse.user.anpanId,
                        walletAddress = loginResponse.user.walletAddress,
                        accessToken = loginResponse.accessToken,
                        refreshToken = loginResponse.refreshToken
                    )
                    userDao.insertUser(userEntity)
                    
                    // Set auth token for API calls
                    authInterceptor.setAuthToken(loginResponse.accessToken)
                    
                    Result.Success(userEntity.toUser())
                } else {
                    Result.Error(Exception(response.body()?.error ?: "Registration failed"))
                }
            } catch (e: Exception) {
                Result.Error(e)
            }
        }
    }
    
    override suspend fun loginWithGoogle(idToken: String): Result<User> {
        return withContext(ioDispatcher) {
            try {
                // Firebase Auth
                val credential = GoogleAuthProvider.getCredential(idToken, null)
                val authResult = firebaseAuth.signInWithCredential(credential).await()
                val firebaseUser = authResult.user ?: throw Exception("Firebase user is null")
                
                // Call API
                val response = authService.googleAuth(
                    com.anpan.core.network.service.GoogleAuthRequest(idToken)
                )
                
                if (response.isSuccessful && response.body()?.success == true) {
                    val loginResponse = response.body()!!.data!!
                    
                    // Save to local database
                    val userEntity = UserEntity(
                        id = loginResponse.user.id,
                        email = loginResponse.user.email,
                        displayName = loginResponse.user.displayName,
                        photoUrl = loginResponse.user.photoUrl,
                        isGuest = false,
                        anpanId = loginResponse.user.anpanId,
                        walletAddress = loginResponse.user.walletAddress,
                        accessToken = loginResponse.accessToken,
                        refreshToken = loginResponse.refreshToken
                    )
                    userDao.insertUser(userEntity)
                    
                    // Set auth token for API calls
                    authInterceptor.setAuthToken(loginResponse.accessToken)
                    
                    Result.Success(userEntity.toUser())
                } else {
                    Result.Error(Exception(response.body()?.error ?: "Google login failed"))
                }
            } catch (e: Exception) {
                Result.Error(e)
            }
        }
    }
    
    override suspend fun loginWithAnpanId(anpanId: String, signature: String): Result<User> {
        return withContext(ioDispatcher) {
            try {
                val response = authService.anpanIdAuth(
                    com.anpan.core.network.service.AnpanIdAuthRequest(anpanId, signature)
                )
                
                if (response.isSuccessful && response.body()?.success == true) {
                    val loginResponse = response.body()!!.data!!
                    
                    // Save to local database
                    val userEntity = UserEntity(
                        id = loginResponse.user.id,
                        email = loginResponse.user.email,
                        displayName = loginResponse.user.displayName,
                        photoUrl = loginResponse.user.photoUrl,
                        isGuest = false,
                        anpanId = loginResponse.user.anpanId,
                        walletAddress = loginResponse.user.walletAddress,
                        accessToken = loginResponse.accessToken,
                        refreshToken = loginResponse.refreshToken
                    )
                    userDao.insertUser(userEntity)
                    
                    // Set auth token for API calls
                    authInterceptor.setAuthToken(loginResponse.accessToken)
                    
                    Result.Success(userEntity.toUser())
                } else {
                    Result.Error(Exception(response.body()?.error ?: "ANPAN ID login failed"))
                }
            } catch (e: Exception) {
                Result.Error(e)
            }
        }
    }
    
    override suspend fun loginAsGuest(): Result<User> {
        return withContext(ioDispatcher) {
            try {
                val guestUser = UserEntity(
                    id = "guest_${UUID.randomUUID()}",
                    email = null,
                    displayName = "Guest User",
                    photoUrl = null,
                    isGuest = true,
                    anpanId = null,
                    walletAddress = null,
                    accessToken = null,
                    refreshToken = null
                )
                
                userDao.insertUser(guestUser)
                Result.Success(guestUser.toUser())
            } catch (e: Exception) {
                Result.Error(e)
            }
        }
    }
    
    override suspend fun logout(): Result<Unit> {
        return withContext(ioDispatcher) {
            try {
                // Firebase logout
                firebaseAuth.signOut()
                
                // API logout
                try {
                    authService.logout()
                } catch (e: Exception) {
                    // Ignore API logout errors
                }
                
                // Clear local data
                userDao.deleteAllUsers()
                authInterceptor.setAuthToken(null)
                
                Result.Success(Unit)
            } catch (e: Exception) {
                Result.Error(e)
            }
        }
    }
    
    override suspend fun refreshToken(): Result<String> {
        return withContext(ioDispatcher) {
            try {
                val currentUser = getCurrentUser()
                if (currentUser?.isGuest == true) {
                    return@withContext Result.Error(Exception("Guest users cannot refresh tokens"))
                }
                
                val userEntity = userDao.getUserById(currentUser?.id ?: "")
                val refreshToken = userEntity?.refreshToken 
                    ?: return@withContext Result.Error(Exception("No refresh token available"))
                
                val response = authService.refreshToken(
                    com.anpan.core.network.service.RefreshTokenRequest(refreshToken)
                )
                
                if (response.isSuccessful && response.body()?.success == true) {
                    val loginResponse = response.body()!!.data!!
                    
                    // Update tokens
                    userDao.updateAccessToken(currentUser?.id ?: "", loginResponse.accessToken)
                    userDao.updateRefreshToken(currentUser?.id ?: "", loginResponse.refreshToken)
                    authInterceptor.setAuthToken(loginResponse.accessToken)
                    
                    Result.Success(loginResponse.accessToken)
                } else {
                    Result.Error(Exception(response.body()?.error ?: "Token refresh failed"))
                }
            } catch (e: Exception) {
                Result.Error(e)
            }
        }
    }
    
    override suspend fun getCurrentUser(): User? {
        return withContext(ioDispatcher) {
            try {
                val users = userDao.getRegisteredUsers()
                users.firstOrNull()?.toUser()
            } catch (e: Exception) {
                null
            }
        }
    }
    
    override fun getCurrentUserFlow(): Flow<User?> {
        return userDao.getUserByIdFlow("current").map { it?.toUser() }
    }
    
    override suspend fun updateProfile(displayName: String?, photoUrl: String?): Result<User> {
        return withContext(ioDispatcher) {
            try {
                val currentUser = getCurrentUser() ?: return@withContext Result.Error(Exception("No user logged in"))
                
                if (currentUser.isGuest) {
                    return@withContext Result.Error(Exception("Guest users cannot update profile"))
                }
                
                val response = authService.updateProfile(
                    com.anpan.core.network.service.UpdateProfileRequest(displayName, photoUrl)
                )
                
                if (response.isSuccessful && response.body()?.success == true) {
                    val updatedProfile = response.body()!!.data!!
                    
                    val userEntity = userDao.getUserById(currentUser.id)?.copy(
                        displayName = updatedProfile.displayName,
                        photoUrl = updatedProfile.photoUrl,
                        updatedAt = System.currentTimeMillis()
                    )
                    
                    userEntity?.let { userDao.updateUser(it) }
                    
                    Result.Success(userEntity?.toUser() ?: currentUser)
                } else {
                    Result.Error(Exception(response.body()?.error ?: "Profile update failed"))
                }
            } catch (e: Exception) {
                Result.Error(e)
            }
        }
    }
    
    override suspend fun deleteAccount(): Result<Unit> {
        return withContext(ioDispatcher) {
            try {
                // Delete Firebase account
                firebaseAuth.currentUser?.delete()?.await()
                
                // Clear local data
                userDao.deleteAllUsers()
                authInterceptor.setAuthToken(null)
                
                Result.Success(Unit)
            } catch (e: Exception) {
                Result.Error(e)
            }
        }
    }
    
    override suspend fun sendPasswordResetEmail(email: String): Result<Unit> {
        return withContext(ioDispatcher) {
            try {
                firebaseAuth.sendPasswordResetEmail(email).await()
                Result.Success(Unit)
            } catch (e: Exception) {
                Result.Error(e)
            }
        }
    }
    
    override suspend fun verifyEmail(): Result<Unit> {
        return withContext(ioDispatcher) {
            try {
                firebaseAuth.currentUser?.sendEmailVerification()?.await()
                Result.Success(Unit)
            } catch (e: Exception) {
                Result.Error(e)
            }
        }
    }
    
    override suspend fun linkAnpanId(anpanId: String, signature: String): Result<User> {
        return withContext(ioDispatcher) {
            try {
                val currentUser = getCurrentUser() ?: return@withContext Result.Error(Exception("No user logged in"))
                
                // Update user with ANPAN ID
                val userEntity = userDao.getUserById(currentUser.id)?.copy(
                    anpanId = anpanId,
                    updatedAt = System.currentTimeMillis()
                )
                
                userEntity?.let { userDao.updateUser(it) }
                
                Result.Success(userEntity?.toUser() ?: currentUser)
            } catch (e: Exception) {
                Result.Error(e)
            }
        }
    }
    
    override suspend fun unlinkAnpanId(): Result<User> {
        return withContext(ioDispatcher) {
            try {
                val currentUser = getCurrentUser() ?: return@withContext Result.Error(Exception("No user logged in"))
                
                // Remove ANPAN ID
                val userEntity = userDao.getUserById(currentUser.id)?.copy(
                    anpanId = null,
                    updatedAt = System.currentTimeMillis()
                )
                
                userEntity?.let { userDao.updateUser(it) }
                
                Result.Success(userEntity?.toUser() ?: currentUser)
            } catch (e: Exception) {
                Result.Error(e)
            }
        }
    }
    
    override suspend fun enableBiometricAuth(): Result<Unit> {
        // Implementation for biometric auth setup
        return Result.Success(Unit)
    }
    
    override suspend fun disableBiometricAuth(): Result<Unit> {
        // Implementation for biometric auth removal
        return Result.Success(Unit)
    }
    
    override suspend fun authenticateWithBiometric(): Result<User> {
        // Implementation for biometric authentication
        return getCurrentUser()?.let { Result.Success(it) } 
            ?: Result.Error(Exception("No user available"))
    }
    
    override fun isLoggedIn(): Boolean {
        return firebaseAuth.currentUser != null
    }
    
    override fun isGuest(): Boolean {
        // Check if current user is guest from local database
        return false // Simplified implementation
    }
    
    private fun UserEntity.toUser(): User {
        return User(
            id = id,
            email = email,
            displayName = displayName,
            photoUrl = photoUrl,
            isGuest = isGuest,
            anpanId = anpanId,
            walletAddress = walletAddress,
            createdAt = createdAt,
            updatedAt = updatedAt
        )
    }
}
