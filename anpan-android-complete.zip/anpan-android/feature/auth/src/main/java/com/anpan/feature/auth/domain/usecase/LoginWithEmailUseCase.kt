package com.anpan.feature.auth.domain.usecase

import com.anpan.core.common.model.User
import com.anpan.core.common.result.Result
import com.anpan.feature.auth.domain.repository.AuthRepository
import javax.inject.Inject

class LoginWithEmailUseCase @Inject constructor(
    private val authRepository: AuthRepository
) {
    suspend operator fun invoke(email: String, password: String): Result<User> {
        if (email.isBlank()) {
            return Result.Error(IllegalArgumentException("Email cannot be empty"))
        }
        
        if (password.isBlank()) {
            return Result.Error(IllegalArgumentException("Password cannot be empty"))
        }
        
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            return Result.Error(IllegalArgumentException("Invalid email format"))
        }
        
        return authRepository.loginWithEmail(email, password)
    }
}
