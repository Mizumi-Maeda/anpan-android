package com.anpan.feature.auth.presentation.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.anpan.core.common.result.Result
import com.anpan.feature.auth.domain.usecase.LoginWithEmailUseCase
import com.anpan.feature.auth.domain.usecase.LoginAsGuestUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val loginWithEmailUseCase: LoginWithEmailUseCase,
    private val loginAsGuestUseCase: LoginAsGuestUseCase
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()
    
    fun onEmailChanged(email: String) {
        _uiState.value = _uiState.value.copy(email = email, emailError = null)
    }
    
    fun onPasswordChanged(password: String) {
        _uiState.value = _uiState.value.copy(password = password, passwordError = null)
    }
    
    fun onLoginClick() {
        val currentState = _uiState.value
        
        if (currentState.isLoading) return
        
        _uiState.value = currentState.copy(
            isLoading = true,
            emailError = null,
            passwordError = null,
            generalError = null
        )
        
        viewModelScope.launch {
            when (val result = loginWithEmailUseCase(currentState.email, currentState.password)) {
                is Result.Success -> {
                    _uiState.value = currentState.copy(
                        isLoading = false,
                        loginSuccess = true
                    )
                }
                is Result.Error -> {
                    val errorMessage = result.exception.message ?: "Login failed"
                    _uiState.value = currentState.copy(
                        isLoading = false,
                        generalError = errorMessage
                    )
                }
                is Result.Loading -> {
                    // Already handled above
                }
            }
        }
    }
    
    fun onGuestLoginClick() {
        val currentState = _uiState.value
        
        if (currentState.isLoading) return
        
        _uiState.value = currentState.copy(isLoading = true)
        
        viewModelScope.launch {
            when (val result = loginAsGuestUseCase()) {
                is Result.Success -> {
                    _uiState.value = currentState.copy(
                        isLoading = false,
                        loginSuccess = true
                    )
                }
                is Result.Error -> {
                    _uiState.value = currentState.copy(
                        isLoading = false,
                        generalError = result.exception.message ?: "Guest login failed"
                    )
                }
                is Result.Loading -> {
                    // Already handled above
                }
            }
        }
    }
    
    fun clearErrors() {
        _uiState.value = _uiState.value.copy(
            emailError = null,
            passwordError = null,
            generalError = null
        )
    }
}

data class LoginUiState(
    val email: String = "",
    val password: String = "",
    val isLoading: Boolean = false,
    val emailError: String? = null,
    val passwordError: String? = null,
    val generalError: String? = null,
    val loginSuccess: Boolean = false
)
