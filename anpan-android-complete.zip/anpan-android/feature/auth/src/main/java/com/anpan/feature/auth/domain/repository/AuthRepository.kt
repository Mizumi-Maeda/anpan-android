package com.anpan.feature.auth.domain.repository

import com.anpan.core.common.model.User
import com.anpan.core.common.result.Result
import kotlinx.coroutines.flow.Flow

interface AuthRepository {
    
    suspend fun loginWithEmail(email: String, password: String): Result<User>
    suspend fun registerWithEmail(email: String, password: String, displayName: String): Result<User>
    suspend fun loginWithGoogle(idToken: String): Result<User>
    suspend fun loginWithAnpanId(anpanId: String, signature: String): Result<User>
    suspend fun loginAsGuest(): Result<User>
    suspend fun logout(): Result<Unit>
    suspend fun refreshToken(): Result<String>
    suspend fun getCurrentUser(): User?
    fun getCurrentUserFlow(): Flow<User?>
    suspend fun updateProfile(displayName: String?, photoUrl: String?): Result<User>
    suspend fun deleteAccount(): Result<Unit>
    suspend fun sendPasswordResetEmail(email: String): Result<Unit>
    suspend fun verifyEmail(): Result<Unit>
    suspend fun linkAnpanId(anpanId: String, signature: String): Result<User>
    suspend fun unlinkAnpanId(): Result<User>
    suspend fun enableBiometricAuth(): Result<Unit>
    suspend fun disableBiometricAuth(): Result<Unit>
    suspend fun authenticateWithBiometric(): Result<User>
    fun isLoggedIn(): Boolean
    fun isGuest(): Boolean
}
