package com.anpan.app.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.anpan.app.ui.MainScreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnpanNavigation(
    navController: NavHostController = rememberNavController()
) {
    NavHost(
        navController = navController,
        startDestination = "main"
    ) {
        composable("main") {
            MainScreen(navController = navController)
        }
        
        // Auth routes
        composable("auth/login") {
            // AuthLoginScreen()
        }
        
        composable("auth/register") {
            // AuthRegisterScreen()
        }
        
        // Social Commerce routes
        composable("social/feed") {
            // SocialFeedScreen()
        }
        
        composable("social/post") {
            // SocialPostScreen()
        }
        
        composable("social/shop") {
            // SocialShopScreen()
        }
        
        // Wallet routes
        composable("wallet/home") {
            // WalletHomeScreen()
        }
        
        // AI routes
        composable("ai/search") {
            // AISearchScreen()
        }
        
        // Chat routes
        composable("chat/list") {
            // ChatListScreen()
        }
        
        // Extension module routes
        composable("music/player") {
            // MusicPlayerScreen()
        }
        
        composable("tv/player") {
            // TVPlayerScreen()
        }
        
        composable("games/list") {
            // GamesListScreen()
        }
        
        composable("map/explore") {
            // MapExploreScreen()
        }
    }
}
