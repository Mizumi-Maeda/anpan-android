package com.anpan.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity

class DeepLinkActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Handle deep links and redirect to MainActivity
        val intent = Intent(this, MainActivity::class.java).apply {
            data = intent.data
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(intent)
        finish()
    }
}
