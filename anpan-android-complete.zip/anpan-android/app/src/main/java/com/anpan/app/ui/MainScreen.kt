package com.anpan.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.anpan.app.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    navController: NavHostController
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    
    val tabs = listOf(
        Triple("home", Icons.Filled.Home, R.string.nav_home),
        Triple("social", Icons.Filled.People, R.string.nav_social),
        Triple("wallet", Icons.Filled.AccountBalanceWallet, R.string.nav_wallet),
        Triple("ai", Icons.Filled.Psychology, R.string.nav_ai),
        Triple("chat", Icons.Filled.Chat, R.string.nav_chat)
    )
    
    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, (route, icon, labelRes) ->
                    NavigationBarItem(
                        icon = { Icon(icon, contentDescription = null) },
                        label = { Text(stringResource(labelRes)) },
                        selected = selectedTab == index,
                        onClick = { 
                            selectedTab = index
                            navController.navigate(route)
                        }
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (selectedTab) {
                0 -> HomeContent()
                1 -> SocialContent()
                2 -> WalletContent()
                3 -> AIContent()
                4 -> ChatContent()
            }
        }
    }
}

@Composable
private fun HomeContent() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "ANPAN ホーム",
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "すべてのANPANサービスにアクセスできます",
            style = MaterialTheme.typography.bodyLarge
        )
    }
}

@Composable
private fun SocialContent() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "ソーシャルコマース",
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "投稿、フィード、ショッピング機能",
            style = MaterialTheme.typography.bodyLarge
        )
    }
}

@Composable
private fun WalletContent() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Kabu Pay ウォレット",
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Web3ウォレット、残高管理、決済機能",
            style = MaterialTheme.typography.bodyLarge
        )
    }
}

@Composable
private fun AIContent() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "ANPAN Brain",
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "AI推薦エンジン、自然言語検索",
            style = MaterialTheme.typography.bodyLarge
        )
    }
}

@Composable
private fun ChatContent() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Chattie",
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "ビデオ通話、チャット、チャットコマース",
            style = MaterialTheme.typography.bodyLarge
        )
    }
}
