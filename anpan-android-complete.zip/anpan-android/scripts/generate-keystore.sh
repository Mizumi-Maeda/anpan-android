#!/bin/bash


set -e

KEYSTORE_DIR="keystore"
mkdir -p "$KEYSTORE_DIR"

if [ "$1" = "debug" ] || [ -z "$1" ]; then
    echo "Generating debug keystore..."
    keytool -genkey -v -keystore "$KEYSTORE_DIR/anpan-debug.keystore" \
        -alias anpan-debug -keyalg RSA -keysize 2048 -validity 10000 \
        -storepass android -keypass android \
        -dname "CN=ANPAN Debug, OU=Development, O=ANPAN, L=Tokyo, S=Tokyo, C=JP"
    echo "Debug keystore created at $KEYSTORE_DIR/anpan-debug.keystore"
fi

if [ "$1" = "release" ]; then
    echo "Generating release keystore..."
    read -p "Enter keystore password: " -s KEYSTORE_PASSWORD
    echo
    read -p "Enter key alias: " KEY_ALIAS
    read -p "Enter key password: " -s KEY_PASSWORD
    echo
    
    keytool -genkey -v -keystore "$KEYSTORE_DIR/anpan-release.keystore" \
        -alias "$KEY_ALIAS" -keyalg RSA -keysize 2048 -validity 25000 \
        -storepass "$KEYSTORE_PASSWORD" -keypass "$KEY_PASSWORD" \
        -dname "CN=ANPAN, OU=Mobile, O=ANPAN Inc, L=Tokyo, S=Tokyo, C=JP"
    
    echo "Release keystore created at $KEYSTORE_DIR/anpan-release.keystore"
    echo "Remember to set these environment variables in your CI/CD:"
    echo "KEYSTORE_PASSWORD=$KEYSTORE_PASSWORD"
    echo "KEY_ALIAS=$KEY_ALIAS"
    echo "KEY_PASSWORD=$KEY_PASSWORD"
fi
