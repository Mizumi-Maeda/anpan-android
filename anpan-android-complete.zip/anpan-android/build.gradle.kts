buildscript {
    extra.apply {
        set("compose_version", "1.5.4")
        set("kotlin_version", "1.9.20")
        set("hilt_version", "2.48")
        set("room_version", "2.6.0")
        set("retrofit_version", "2.9.0")
        set("okhttp_version", "4.12.0")
        set("coroutines_version", "1.7.3")
        set("lifecycle_version", "2.7.0")
        set("navigation_version", "2.7.5")
        set("accompanist_version", "0.32.0")
        set("coil_version", "2.5.0")
        set("exoplayer_version", "2.19.1")
        set("agora_version", "4.2.6")
        set("web3j_version", "4.10.3")
        set("mapbox_version", "10.16.0")
        set("firebase_version", "32.6.0")
        set("stripe_version", "20.34.0")
    }
}

plugins {
    id("com.android.application") version "8.1.4" apply false
    id("com.android.library") version "8.1.4" apply false
    id("org.jetbrains.kotlin.android") version "1.9.20" apply false
    id("com.google.dagger.hilt.android") version "2.48" apply false
    id("com.google.gms.google-services") version "4.4.0" apply false
    id("com.google.firebase.crashlytics") version "2.9.9" apply false
    id("org.jetbrains.kotlin.plugin.parcelize") version "1.9.20" apply false
    id("org.jetbrains.kotlin.plugin.serialization") version "1.9.20" apply false
}

allprojects {
    configurations.all {
        resolutionStrategy {
            force("org.bouncycastle:bcprov-jdk18on:1.73")
            exclude(group = "org.bouncycastle", module = "bcprov-jdk15to18")
        }
    }
}
